<?php

$BD_URL = "localhost";
$BD_USUARIO = "root";
$BD_SENHA = "";
$BD_BANCO = "trabalho";

//Cria a conexão
$conexao = mysqli_connect($BD_URL, $BD_USUARIO, $BD_SENHA, $BD_BANCO);

?>