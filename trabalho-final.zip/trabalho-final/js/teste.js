$(document).ready(function(){
    alert('ola, mundo!');
})